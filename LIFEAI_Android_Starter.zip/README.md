# LIFEAI

LIFEAI is an Android-first everyday AI hub starter project.

## Current MVP

- Home dashboard
- Universal search over built-in features
- AI assistant screen (UI only; connect an AI backend/API)
- Original story listing
- Profile/settings UI
- Free Fire redeem-code information placeholder
- Study, local, tools, courses, travel and creative feature cards

## Open in Android Studio

1. Download or clone this repository.
2. Open the `LIFEAI` folder in Android Studio.
3. Let Gradle sync.
4. Run the `app` configuration on an Android emulator or phone.

## Important

This repository is a starter MVP. Real AI, maps, accounts, databases, audio streaming, notifications and live redeem-code information require backend services and API integrations.

Do not put API keys directly in the Android source code.

## License

Add the license you want before publishing.
